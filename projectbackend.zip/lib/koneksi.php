<?php 
	$con = new mysqli('localhost','root','rpl12345','erdinventor');
 ?>