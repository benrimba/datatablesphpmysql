<table id="example" class="table table-striped table-bordered" style="width:100%">
	<thead>
		<tr>
			<td>No</td>
			<td>Kode Supplier</td>
			<td>Nama Supplier</td>
			<td>Alamat</td>
			<td>Telp</td>
			<td>Aksi</td>
		</tr>
	</thead>
	<tbody>
		<?php 
			$no=1;
			$sql = $con->query("SELECT*FROM supplier");
			while ($rView=$sql->fetch_array()) {
				?>			
		<tr>	
			<td><?=$no++?></td>
			<td><?=$rView['kode_supplier']?></td>
			<td><?=$rView['nama_supplier']?></td>
			<td><?=$rView['alamat']?></td>
			<td><?=$rView['telepon']?></td>

			<td>
				<a href="">Edit</a> | <a href="">Delete</a>

			</td>
			
		</tr>
		<?php 
		}
		 ?>
		
	</tbody>
</table>