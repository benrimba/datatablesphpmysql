<?php 
	include"lib/koneksi.php";
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
</head>
<body>
	<a href="?page=sup">Data Supplier</a>
	<div class="container mt-5">
		<?php 
		$page=isset($_GET['page'])?$_GET['page']:null;
		switch ($page) {
			case 'sup':
				include"modul/supplier.php";
				break;
			
			default:
				echo "<h1>SELAMAT DATANG</h1>";
				break;
		}
	 ?>
		
	</div>
	

	 <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
	 <script type="text/javascript" src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
	 <script type="text/javascript" src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
	 <script type="text/javascript">
	 	$(document).ready(function () {
			    $('#example').DataTable();
			});
	 </script>

</body>
</html>